export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyC73lW93bPehX_76UtsC1SXRmMaWyMnHZA",
    authDomain: "futapp-1d324.firebaseapp.com",
    projectId: "futapp-1d324",
    storageBucket: "futapp-1d324.appspot.com",
    messagingSenderId: "1005940865030",
    appId: "1:1005940865030:web:abfadcb115676899c8eb87",
    measurementId: "G-56SGS668W2"
  }
};
