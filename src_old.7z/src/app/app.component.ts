import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Campeonatos', url: '/folder/inbox', icon: 'list' },
    { title: 'Time Favorito', url: '/folder/favorites', icon: 'heart' },
    { title: 'Sair', url: '/folder/outbox', icon: 'log-out' },
    //{ title: 'Archived', url: '/folder/archived', icon: 'archive' },
    //{ title: 'Trash', url: '/folder/trash', icon: 'trash' },
    //{ title: 'Spam', url: '/folder/spam', icon: 'warning' },
  ];
  //public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
  constructor() {}
}
//<ion-icon name="log-out-outline"></ion-icon>