// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyC73lW93bPehX_76UtsC1SXRmMaWyMnHZA",
    authDomain: "futapp-1d324.firebaseapp.com",
    projectId: "futapp-1d324",
    storageBucket: "futapp-1d324.appspot.com",
    messagingSenderId: "1005940865030",
    appId: "1:1005940865030:web:abfadcb115676899c8eb87",
    measurementId: "G-56SGS668W2"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.








// apiKey: "AIzaSyCAaZjDzPFnb47OJYlvAB8AqzDuI8Qnh7w",
// authDomain: "futapp-88b28.firebaseapp.com",
// projectId: "futapp-88b28",
// storageBucket: "futapp-88b28.appspot.com",
// messagingSenderId: "651666427766",
// appId: "1:651666427766:web:570efe1e62dc4b24f87457",
// measurementId: "G-M4YJ49JMWJ"